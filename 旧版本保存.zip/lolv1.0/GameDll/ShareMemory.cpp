#include "stdafx.h"
#include "ShareMemory.h"

